﻿/*
FindMeMeetingRooms.js
Microsoft grants you the right to use these script files for the sole purpose of either (i) interacting through your browser with the website or online service, subject to the applicable licensing or use terms; or (ii) using the files as included with a Microsoft product subject to that product’s license terms. Microsoft reserves all other rights to the files not expressly granted by Microsoft, whether by implication, estoppel or otherwise. The notices and licenses below are for informational purposes only.
*/
var showOccupiedDesks = false;
var showMeetingTimeSliders = false;
var roomsByLevel = [];
var meetingsByLevel = [];
var foundBuilding = '~';
var foundLevel = '~';
var minSeats = 0;
var capabilityFilter = 0;
var selectedDateTime = new Date();

function initialiseDatePicker() {

    $("#meetingDatePicker").datepicker(
        {
            minDate: 0,
            maxDate: 7,
            onSelect: function (dateString) {
                var date = $("#meetingDatePicker").datepicker("getDate");
                var targetDate;
                var now = new Date();
                if (date.getFullYear() == now.getFullYear() && date.getMonth() == now.getMonth() && date.getDate() == now.getDate()) {
                    // It's today
                    targetDate = now;
                } else {
                    // Day starts at 8am
                    targetDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 8, 0, 0, 0);
                    clearOccupiedDesks();
                }

                initialiseTimeSlider(targetDate);

                $("#meetingTime").text(toTimeString(targetDate, false));
                highlightRoomsInAllLevels(targetDate);
            },
        });
    $("#meetingDatePicker").datepicker("option", "dateFormat", "D d MM yy");
    $("#meetingDatePicker").datepicker("setDate", new Date());

}

function initialiseFilters() {
    $('#minSeats').on('change', function () {
        //action here
        minSeats = $(this).val();
        highlightRoomsInAllLevels(selectedDateTime);
        //alert("Changed to " + minSeats);
    });
    $('#capabilities').on('change', function () {
        //action here
        capabilityFilter = $(this).val();
        highlightRoomsInAllLevels(selectedDateTime);
        //alert("Changed to " + minSeats);
    });
}

function initialiseTimeSlider(date) {
    if ($('#slider').length != 0) {
        $("#meetingTime").text(toTimeString(date, false));

        var startToday = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 8, 0, 0, 0);
        var endToday = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 18, 0, 0, 0);

        var initialValue = date.getHours() < 18 ? date : endToday;

        var tickLabels = [];

        for (var i = 0; i <= 10; i++) {
            time = new Date(startToday.getTime());
            time.addHours(i);
            tickLabels[time.getTime()] = toTimeString(time);
        }

        $("#slider").labeledslider({
            value: initialValue,
            min: startToday.getTime(),
            max: endToday.getTime(),
            step: 1800000, // 30 mins
            tickInterval: 3600000,
            tickLabels: tickLabels,
            slide: function (event, ui) {

                clearOccupiedDesks();

                var now = new Date();
                if (ui.value < now.getTime()) {

                    $("#meetingTime").text(toTimeString(now, false));
                    highlightRoomsInAllLevels(now);
                    $("#slider").labeledslider('value', now.getTime());
                    return false;
                }

                $("#meetingTime").text(toTimeString(new Date(ui.value), false));
                selectedDateTime = new Date(ui.value);
                highlightRoomsInAllLevels(new Date(ui.value));

            }

        });
    }
}

function setUserBuildingAndLevel(userId) {
    var currentBuilding = null;
    var findUserUrl = serviceLocation + '/ObjectLocation/Users/' + userId;

    $.getJSON(findUserUrl, function (messageLocations) {
        if (messageLocations.length != 0) {
            if (messageLocations[0].Status == 'Located') {
                foundBuilding = messageLocations[0].Coordinates.Building;
                foundLevel = messageLocations[0].Coordinates.Level;
            }
        }
    });
}

function drawMapAndShowMeetings(building, level) {

    if (!showPeopleUI) {
        $('.peopleUI').addClass("hidden");
    }
    setUserBuildingAndLevel(currentUserId);

    var meetingLevelSummaryUrl = serviceLocation + '/MeetingRooms/BuildingLevelsWithMeetingRooms';

    $.getJSON(meetingLevelSummaryUrl, function (summaryLocations) {

        if (building == "~")
            building = foundBuilding;

        if (building == "~") {
            if (summaryLocations.length >= 1) {
                building = summaryLocations[0].Building;
            }
        }
        showMeetingLevelSummary(summaryLocations, building);

        if (building != null && building != "") {

            expandBuilding(building);

            var locations = [];

            if (level == "~")
                level = foundLevel;

            if (level == "~") {
                //shortcut for the first floor
                // create single dummy entity
                for (var i in summaryLocations) {
                    var location = summaryLocations[i];
                    if (location.Building == building) {
                        locations.push({ LocationIdentifier: "d" + building + location.Level, LocatedUsing: 'FixedLocation', Coordinates: { Building: building, Level: location.Level } })
                        break;
                    }
                }
            }
            else if (level != "*") {
                // if we have both building an level, create single dummy entity
                locations.push({ LocationIdentifier: "d" + building + level, LocatedUsing: 'FixedLocation', Coordinates: { Building: building, Level: level } });
                showInternalMapWithLocations(locations);
            }
            else {
                // if we have just buliding, or building and level, create dummy entity for each level
                for (var i in summaryLocations) {
                    var location = summaryLocations[i];
                    if (location.Building == building) {
                        locations.push({ LocationIdentifier: "d" + building + location.Level, LocatedUsing: 'FixedLocation', Coordinates: { Building: building, Level: location.Level } })
                    }
                }
            }

            showInternalMapWithLocations(locations);
        }
        // if we have neither, try to get the level of the current uer
        else {
            tryShowCurrentLevel();
        }
    });
}

function tryShowCurrentLevel() {
    var findMeServiceUrl = serviceLocation + '/ObjectLocation/Users/' + currentUserId + '?getExtendedData=true';

    $.getJSON(findMeServiceUrl, function (data) {
        if (data.length == 1) {
            myLocation = data[0];
            if (myLocation.Coordinates != null && myLocation.Coordinates.Building != null) {

                var locations = [{ LocationIdentifier: "d" + myLocation.Coordinates.Building + myLocation.Coordinates.Level, LocatedUsing: 'FixedLocation', Coordinates: myLocation.Coordinates }];

                showInternalMapWithLocations(locations);
                expandBuilding(myLocation.Coordinates.Building);
            }
        }
    });
}

function showMeetingLevelSummary(summaryLocations) {

    for (var location in summaryLocations) {

        var thisLocation = summaryLocations[location];

        var identifier = thisLocation.Building;

        if ($('#personList_box_' + identifier).length == 0) {

            $('<h3/>', {
                id: 'sidebar-caption-' + identifier,
                text: thisLocation.Building.replace(/_/g, " "),
            }).appendTo('#roomList');

            $('<div/>', {
                id: 'personList_box_' + identifier,
                class: 'buildingList_box'
            }).appendTo('#roomList');

            $('<div/>', {
                id: 'personList_text_' + identifier,
                class: 'buildingList_text'
            }).appendTo('#personList_box_' + identifier);

            $('<span/>', {
                id: 'levelspan' + thisLocation.Building + 'all',
                class: 'smallText',
            }).appendTo('#personList_text_' + identifier);

            $("<a href='" + $.url("MeetingRooms/" + thisLocation.Building + '/*') + "'>" + 'All</a>').appendTo('#levelspan' + thisLocation.Building + 'all');
        }

        $('<span/>', {
            id: 'levelspan' + thisLocation.Building + thisLocation.Level,
            class: 'smallText narrow',
        }).appendTo('#personList_text_' + identifier);

        $("<a href='" + $.url("MeetingRooms/" + thisLocation.Building + '/' + thisLocation.Level) + "'>" + 'Level ' + thisLocation.Level + '</a>').appendTo('#levelspan' + thisLocation.Building + thisLocation.Level);

        $('<span/>', {
            text: thisLocation.Online + ' rooms',
            class: 'smallText wide',
        }).appendTo('#personList_text_' + identifier);
    }

    $("#roomList").accordion({ collapsible: true, active: false, heightStyle: "content" });
    $("#roomList").accordion("option", "icons", null);

}

function expandBuilding(building) {

    var index = $("#roomList h3").index($("#sidebar-caption-" + building));

    if (index >= 0) {
        $("#roomList").accordion("option", "active", index);
    }
}

function showMeetingsForLevel(building, level) {

    var startDate = new Date();
    var endDate = new Date();
    endDate.setDate(startDate.getDate() + 9);

    var meetingsUrl = serviceLocation + '/MeetingRooms/Meetings/' + building + '/' + level +
        '/' + startDate.toISOString() + '/' + endDate.toISOString();

    $.getJSON(meetingsUrl, function (meetings) {
        meetingsByLevel[meetingsByLevel.length] = meetings;

        var roomsUrl = serviceLocation + '/MeetingRooms/Level/' + building + '/' + level;
        $.getJSON(roomsUrl, function (rooms) {

            roomsByLevel[roomsByLevel.length] = setRoomCapabilities(rooms);

            highlightRooms(new Date(), meetings, rooms);

            if (showOccupiedDesks) // Don't show this on people finding page
                highlightOccupiedDesks(building, level);
        });
    });

    setTimeout('refreshView("' + building + '", "' + level + '")', 300000); // Refresh in 5 minutes
}

function setRoomCapabilities(rooms) {
    for (var id in rooms) {
        var room = rooms[id];
        var capabilities =
            ((room.HasAV === true) * 1)
            + ((room.HasSpeakerPhone === true) * 2)
            + ((room.HasDeskPhone === true) * 4)
            + ((room.HasWhiteboard === true) * 8)
            + ((room.HasTelepresence === true) * 16);
        room.Capabilities = capabilities;
    }
    return rooms;
}

function refreshView(building, level) {
    showMeetingsForLevel(building, level);
    initialiseDatePicker();
    initialiseFilters();
    initialiseTimeSlider(new Date());
}

function highlightRoomsInAllLevels(now) {
    for (var id in meetingsByLevel) {
        var meetings = meetingsByLevel[id];
        var rooms = roomsByLevel[id];
        highlightRooms(now, meetings, rooms);
    }
}

function highlightRooms(now, meetings, rooms) {

    var roomMeetingStatus = {};
    for (var id in meetings) {
        var meeting = meetings[id];

        if (roomMeetingStatus[meeting.ConferenceRoomAlias] == null)
            roomMeetingStatus[meeting.ConferenceRoomAlias] = {};

        var meetingStart = Date.parse(meeting.Start);
        var meetingEnd = Date.parse(meeting.End);

        if (meetingEnd <= now) {
            // Meeting is done - ignore
            continue;
        }

        if (meetingStart > now && new Date(meetingStart).getDate() != now.getDate()) {
            // Meeting isn't today (probably tomorrow) - ignore
            continue;
        }

        if (meetingStart <= now && meetingEnd >= now) {
            // This meeting is on now
            roomMeetingStatus[meeting.ConferenceRoomAlias].currentMeetingSubject = meeting.Subject;
            roomMeetingStatus[meeting.ConferenceRoomAlias].currentMeetingStart = meetingStart;
            roomMeetingStatus[meeting.ConferenceRoomAlias].currentMeetingEnd = meetingEnd;
            roomMeetingStatus[meeting.ConferenceRoomAlias].freeUntil = null;
            roomMeetingStatus[meeting.ConferenceRoomAlias].busyUntil = meetingEnd;
        }
        else {
            // This meeting is in the future
            // Update freeUntil if this meeting starts before any others
            if (roomMeetingStatus[meeting.ConferenceRoomAlias].freeUntil == null ||
                roomMeetingStatus[meeting.ConferenceRoomAlias].freeUntil > meetingStart) {

                roomMeetingStatus[meeting.ConferenceRoomAlias].freeUntil = meetingStart;
            }

            if (roomMeetingStatus[meeting.ConferenceRoomAlias].busyUntilIdentified) {
                // If we've previously found a gap between meetings, don't look ahead
                continue;
            }

            if (meetingStart > roomMeetingStatus[meeting.ConferenceRoomAlias].busyUntil) {
                // There is a gap after the last meeting - the previous busyUntl is correct
                roomMeetingStatus[meeting.ConferenceRoomAlias].busyUntilIdentified = true;
            } else {
                // No gap - the busyUntil is at least the end of this meeting
                roomMeetingStatus[meeting.ConferenceRoomAlias].busyUntil = meetingEnd;
            }
        }
    }

    for (var id in rooms) {
        var room = rooms[id];

        if (roomMeetingStatus[room.Alias] == null)
            roomMeetingStatus[room.Alias] = {};

        if (roomMeetingStatus[room.Alias].currentMeetingSubject == null) {
            cssClass = 'meetingRoomFree';
            if (roomMeetingStatus[room.Alias].freeUntil == null)
                busyStatus = 'Free';
            else
                busyStatus = 'Free until ' + toTimeString(roomMeetingStatus[room.Alias].freeUntil, true);
        }
        else {
            cssClass = 'meetingRoomBusy';
            busyStatus = 'Busy until ' + toTimeString(roomMeetingStatus[room.Alias].busyUntil, true);
        }

        if (roomMeetingStatus[room.Alias].currentMeetingSubject == null)
            meetingSubject = '';
        else
            meetingSubject = roomMeetingStatus[room.Alias].currentMeetingSubject;

        var roomElement = $('#' + room.Building + '_' + room.Level).find('#' + room.LocationDescription.replace(/\./g, "\\."));


        bookMeetingStart = roomMeetingStatus[room.Alias].currentMeetingSubject == null ? now.toISOString() : new Date(roomMeetingStatus[room.Alias].busyUntil).toISOString();

        var roomFeatures = room.Features == null ? '' : room.Features;
        var decodedroomPhotoSASSuffix = roomPhotoSASSuffix.replace(/&amp;/g, '&');
        var photoUrlQuoted = room.PhotoUrl == null ? 'null' : '\'' + room.PhotoUrl + decodedroomPhotoSASSuffix + '\'';

        roomElement.attr('onmouseenter', 'showMeetingStatus(\'' + room.Name.replace(/'/g, "\\'") + '\', \'' + room.Alias + '\', \'' + room.Building + '\', \'' +
            busyStatus + '\', \'' + meetingSubject.replace(/'/g, "\\'") + '\', \'' + bookMeetingStart + '\', ' + room.CanBeBooked +
            ', ' + room.Capacity + ', ' + room.HasAV + ', ' + room.HasSpeakerPhone + ', ' + room.HasDeskPhone + ', ' + room.HasWhiteboard +
            ', \'' + roomFeatures.replace(/'/g, "\\'") + '\', ' + photoUrlQuoted + ', this)');

        roomElement.attr('onmouseleave', 'hideMeetingStatus()');

        roomElement.removeClass('meetingRoomFree');
        roomElement.removeClass('meetingRoomBusy');
        roomElement.removeClass('meetingRoomFilteredOut');
        newCssClass = filterRoom(cssClass, room);
        roomElement.addClass(newCssClass);
    }

}

function filterRoom(cssClass, room) {
    if (room.Capacity < minSeats)
        cssClass = 'meetingRoomFilteredOut';
    if ((room.Capabilities & capabilityFilter) != capabilityFilter)
        cssClass = 'meetingRoomFilteredOut';
    if ((room.Capabilities === 0) && (capabilityFilter === -1))
        cssClass = 'meetingRoomFilteredOut';
    return cssClass;
}

function showMeetingStatus(roomName, roomAlias, building, busyStatus, currentMeeting, bookMeetingStart, canBeBooked, capacity, hasAV, hasSpeakerPhone, hasDeskPhone, hasWhiteboard, features, photoUrl, element) {

    clearTimeout($(this).data('timeoutId'));

    $('#meetingDetailsRoomName').text(roomName);
    if (currentMeeting == '') {
        $('#meetingDetailsCurrentMeeting').hide();
    }
    else {
        $('#meetingDetailsCurrentMeeting').show();
        $('#meetingDetailsCurrentMeeting').text(currentMeeting);
    }
    $('#meetingDetailsBusyStatus').text(busyStatus);

    $('#meetingDetailsBookRoomLink').attr('href', $('#meetingDetailsBookRoomRawLink').attr('href') + '?roomAlias=' + roomAlias + '&roomName=' + roomName + '&building=' + building
        + '&start=' + bookMeetingStart);

    if (canBeBooked) {
        $('#meetingDetailsBookRoomLink').show();
    } else {
        $('#meetingDetailsBookRoomLink').show();
    }

    if (capacity == null) {
        $('#meetingRoomCapacity').hide();
    } else {
        $('#meetingRoomCapacity').show();
        $('#meetingRoomCapacity').text(capacity);
    }

    $('#meetingRoomAdditionalFeatures').text(features);

    if (hasAV) {
        $('#meetingRoomHasAV').show();
    } else {
        $('#meetingRoomHasAV').hide();
    }

    if (hasSpeakerPhone) {
        $('#meetingRoomHasSpeakerPhone').show();
    } else {
        $('#meetingRoomHasSpeakerPhone').hide();
    }

    if (hasDeskPhone) {
        $('#meetingRoomHasDeskPhone').show();
    } else {
        $('#meetingRoomHasDeskPhone').hide();
    }

    if (hasWhiteboard) {
        $('#meetingRoomHasWhiteboard').show();
    } else {
        $('#meetingRoomHasWhiteboard').hide();
    }

    if (photoUrl != null) {
        $('#meetingDetailsPhoto').show();
        $('#meetingRoomPhoto').attr('src', photoUrl);
    } else {
        $('#meetingDetailsPhoto').hide();
    }

    $('#meetingDetails').show();
    $('#meetingDetails').position({
        my: "left bottom",
        at: "right top",
        of: element,
        collision: "fit"
    });



}

function hideMeetingStatus() {
    var someElement = $(this),
        timeoutId = setTimeout(function () {
            $('#meetingDetails').fadeOut("slow");
        }, 3000);
    //set the timeoutId, allowing us to clear this trigger if the mouse comes back over
    someElement.data('timeoutId', timeoutId);

}

function toTimeString(dateNumber, includeDateIfNotToday) {
    var date = new Date(dateNumber);

    var day = date.getDate();
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var month = monthNames[date.getMonth()];
    var year = date.getFullYear();

    var hour = date.getHours();
    var minute = date.getMinutes();
    var ap = "AM";
    if (hour > 11) { ap = "PM"; }
    if (hour > 12) { hour = hour - 12; }
    if (hour == 0) { hour = 12; }
    if (minute < 10) { minute = "0" + minute; }
    var timeString = hour + ':' + minute + " " + ap;

    if (day != new Date().getDate() && includeDateIfNotToday) {
        timeString = day + "-" + month + "-" + year + " " + timeString;
    }

    return timeString;
}

Date.prototype.addHours = function (h) {
    this.setHours(this.getHours() + h);
    return this;
}

function clearOccupiedDesks() {
    $('.meetingRoomOccupied').removeClass('meetingRoomOccupied');
}

function highlightOccupiedDesks(building, level) {
    var findMeServiceUrl = serviceLocation + '/ObjectLocation/Level/' + building + '/' + level;

    $.getJSON(findMeServiceUrl, function (locations) {
        $('.meetingRoomOccupied').removeClass('meetingRoomOccupied');

        for (var index in locations) {
            var location = locations[index];

            if (location.LocatedUsing == 'FixedLocation' || location.LocatedUsing == 'LLDPLocation') { //&& location.Status == 'Located' && location.Coordinates.LocationDescription != null) {
                var locationDivId = location.Coordinates.Building + '_' + location.Coordinates.Level;
                var svg = $('#' + locationDivId).svg('get');
                if (!location.MapByLocationId) {
                    drawOccupiedDesk(svg, location);
                }
            }

        }
    });
}

function drawOccupiedDesk(svg, location) {

    var label = location.Alias;

    var x;
    var y;

    var mapWidth = svg.root().viewBox.baseVal.width;
    var scale = mapWidth / 10000;
    var wifiScale = location.WiFiScale;

    if (location.Coordinates.X != null) {
        // offset and scale specific to current map, as defined in the viewbox
        var xOffset = svg.root().viewBox.baseVal.x;
        var yOffset = svg.root().viewBox.baseVal.y;

        x = (scale * location.Coordinates.X) + xOffset;
        y = (scale * location.Coordinates.Y) + yOffset;
    }

    var circleRadius = 100 * scale * wifiScale;
    var cssClass = 'occupiedDesk' + location.Status;
    svg.circle(x, y, circleRadius, { class: cssClass, id: location.Name + 'circle', onclick: 'onPointClick("' + location.Name + '")' });
}

function drawMedicalIcon(svg, cx, cy, radius) {
    var scale = (35.6 / radius)
    //var g = svg.group({ transform: 'translate(270 80) rotate(-30)' });
    var movestr = 'translate(' + (cx - radius) + ' ' + (cy - radius) + ')';
    var moveGroup = svg.group({ transform: movestr });
    var csx = -36.1 * (scale - 1); var csy = -36.1 * (scale - 1);
    var transformstr = 'translate(' + csx + ' ' + csy + ') scale(' + scale + ')';
    var iconGroup = svg.group(moveGroup, { transform: transformstr });
}

function showLocationLabel(name) {
    $('#' + safeId(name) + 'text').show();
}

function hideLocationLabel(name) {
    $('#' + safeId(name) + 'text').hide();
}



